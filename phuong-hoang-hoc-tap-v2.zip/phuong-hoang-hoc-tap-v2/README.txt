PHUONG HOANG HOC TAP - PHIEN BAN NANG CAP

Cach xem thu:
1. Mo file index.html bang Edge/Chrome de kiem tra tren may tinh.
2. Khi muon cap nhat GitHub Pages: vao repository phuong-hoang-hoc-tap.
3. Chon Add file > Upload files.
4. Keo file index.html moi vao, ghi de file index.html cu.
5. Commit changes.
6. Cho GitHub Pages cap nhat, sau do mo lai website.

Luu y:
- Ban nay la website tinh, cac diem va tien do duoc luu trong localStorage cua trinh duyet dang dung.
- Diem chua dong bo giua nhieu thiet bi/nguoi dung.
- Noi dung hien la bo bai hoc mau de xay dung tiep, can duoc bien tap va bo sung truoc khi dung nhu chuong trinh hoc chinh thuc.
